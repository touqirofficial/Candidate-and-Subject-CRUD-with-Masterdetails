﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CoreMasterdetails.Models
{
    public class Result
    {
        public int Id { get; set; }
        [ForeignKey("Candidate")]
        public int CandidateId { get; set; }
        [ForeignKey("Subject")]
        public int SubjectId { get; set; }
        public int Marks { get; set; }

        //nev
        public Candidate? Candidate { get; set; }
        public Subject? Subject { get; set; }
    }
}
