﻿namespace CoreMasterdetails.Models
{
    public class Subject
    {
        public int SubjectId { get; set; }
        public string SubjectName { get; set; } = default!;

        public ICollection<CandidateSubject> CandidateSubjects { get; set;}= new List<CandidateSubject>();
        public ICollection<Result> Results { get; set; }= new List<Result>();
    }
}
